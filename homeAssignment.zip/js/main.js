'use strict'

function init() {
    initLinks()
}